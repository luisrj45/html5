export function suma (a, b) {
  return a + b
}
