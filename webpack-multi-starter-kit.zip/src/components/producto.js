export function producto (a, b) {
  return a * b
}
