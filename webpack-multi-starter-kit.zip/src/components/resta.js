export default function resta (a, b) {
  return a - b
}
